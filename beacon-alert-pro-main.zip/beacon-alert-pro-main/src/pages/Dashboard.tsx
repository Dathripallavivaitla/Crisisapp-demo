import { useEffect, useMemo, useState } from "react";
import { TopBar } from "@/components/TopBar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Activity, AlertTriangle, CheckCircle2, ChevronRight, Clock, Flame, HeartPulse, MapPin, ShieldAlert, Sparkles, Timer, TrendingUp, Users } from "lucide-react";
import { useIncidentStore } from "@/lib/incident-store";
import { useAuthStore } from "@/lib/auth-store";
import type { Incident, IncidentStatus } from "@/lib/types";
import { EMERGENCY_META, STATUS_META } from "@/lib/constants";
import { severityBg } from "@/lib/ai";
import { IncidentsMap } from "@/components/IncidentsMap";
import { AnalyticsCharts } from "@/components/AnalyticsCharts";
import { StaffChat } from "@/components/StaffChat";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";

const TYPE_ICON = { fire: Flame, medical: HeartPulse, security: ShieldAlert, evacuation: AlertTriangle, other: Activity } as const;

type FilterStatus = "all" | IncidentStatus;

export default function Dashboard() {
  const user = useAuthStore((s) => s.user)!;
  const incidents = useIncidentStore((s) => s.incidents);
  const responders = useIncidentStore((s) => s.responders);
  const updateStatus = useIncidentStore((s) => s.updateStatus);
  const assignResponder = useIncidentStore((s) => s.assignResponder);
  const unassignResponder = useIncidentStore((s) => s.unassignResponder);

  const [filter, setFilter] = useState<FilterStatus>("all");
  const [selectedId, setSelectedId] = useState<string | null>(null);

  // Auto-select most urgent on mount
  useEffect(() => {
    if (selectedId) return;
    const sorted = [...incidents].filter((i) => i.status !== "resolved").sort((a, b) => b.priorityScore - a.priorityScore);
    if (sorted[0]) setSelectedId(sorted[0].id);
  }, [incidents, selectedId]);

  // Surface high-severity new incidents as toasts (simulated realtime).
  const seenIds = useMemo(() => new Set<string>(), []);
  useEffect(() => {
    incidents.forEach((i) => {
      if (seenIds.has(i.id)) return;
      seenIds.add(i.id);
      const ageSec = (Date.now() - i.createdAt) / 1000;
      if (ageSec < 5 && (i.severity === "high" || i.severity === "critical")) {
        toast.error(`${i.severity.toUpperCase()} ${EMERGENCY_META[i.type].label} — ${i.location.label ?? "venue"}`, {
          description: i.description,
        });
      }
    });
  }, [incidents, seenIds]);

  const filtered = useMemo(() => {
    const list = filter === "all" ? incidents : incidents.filter((i) => i.status === filter);
    return [...list].sort((a, b) => {
      if (a.status === "resolved" && b.status !== "resolved") return 1;
      if (b.status === "resolved" && a.status !== "resolved") return -1;
      return b.priorityScore - a.priorityScore || b.createdAt - a.createdAt;
    });
  }, [incidents, filter]);

  const selected = incidents.find((i) => i.id === selectedId) ?? filtered[0] ?? null;

  const stats = useMemo(() => {
    const active = incidents.filter((i) => i.status !== "resolved").length;
    const critical = incidents.filter((i) => i.severity === "critical" && i.status !== "resolved").length;
    const resolved = incidents.filter((i) => i.status === "resolved");
    const avgMin = resolved.length > 0
      ? resolved.reduce((a, i) => a + ((i.resolvedAt! - i.createdAt) / 60000), 0) / resolved.length
      : 0;
    const panicClusters = incidents.filter((i) => i.panicCluster && i.status !== "resolved").length;
    return { active, critical, avgMin, panicClusters, total: incidents.length };
  }, [incidents]);

  return (
    <div className="min-h-screen bg-background">
      <TopBar />
      <main className="mx-auto max-w-[1400px] space-y-6 px-4 py-6 md:px-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold tracking-tight md:text-3xl">Live Operations</h1>
            <p className="text-sm text-muted-foreground">Welcome back, {user.name.split(" ")[0]} — {user.department ?? "Operations"}.</p>
          </div>
          {stats.panicClusters > 0 && (
            <Badge variant="outline" className="animate-blink-alert border-severity-critical/50 bg-severity-critical/15 text-severity-critical">
              <AlertTriangle className="mr-1.5 h-3.5 w-3.5" />
              {stats.panicClusters} panic cluster{stats.panicClusters > 1 ? "s" : ""} detected
            </Badge>
          )}
        </div>

        {/* KPI strip */}
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          <KpiCard icon={Activity} label="Active incidents" value={stats.active} accent="primary" />
          <KpiCard icon={AlertTriangle} label="Critical" value={stats.critical} accent="critical" />
          <KpiCard icon={Timer} label="Avg response" value={stats.avgMin > 0 ? `${stats.avgMin.toFixed(1)}m` : "—"} accent="info" />
          <KpiCard icon={TrendingUp} label="Total tracked" value={stats.total} accent="success" />
        </div>

        {/* Map + Feed */}
        <div className="grid gap-4 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <IncidentsMap incidents={incidents} selectedId={selectedId} onSelect={setSelectedId} />
          </div>

          <Card className="border-border/60 bg-card/60">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">Incident feed</CardTitle>
                <Tabs value={filter} onValueChange={(v) => setFilter(v as FilterStatus)}>
                  <TabsList className="h-8">
                    <TabsTrigger value="all" className="h-6 px-2 text-xs">All</TabsTrigger>
                    <TabsTrigger value="pending" className="h-6 px-2 text-xs">Pending</TabsTrigger>
                    <TabsTrigger value="in_progress" className="h-6 px-2 text-xs">Active</TabsTrigger>
                    <TabsTrigger value="resolved" className="h-6 px-2 text-xs">Resolved</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[360px] px-2">
                <div className="space-y-1 px-2 pb-2">
                  {filtered.length === 0 && <p className="py-12 text-center text-sm text-muted-foreground">No incidents match this filter.</p>}
                  {filtered.map((i) => {
                    const Icon = TYPE_ICON[i.type];
                    const active = selected?.id === i.id;
                    return (
                      <button
                        key={i.id}
                        type="button"
                        onClick={() => setSelectedId(i.id)}
                        className={`group w-full rounded-lg border p-3 text-left transition-all ${active ? "border-primary bg-primary/10 shadow-glow" : "border-border/40 bg-secondary/30 hover:border-primary/40 hover:bg-secondary/60"}`}
                      >
                        <div className="flex items-start gap-3">
                          <div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${severityBg(i.severity)}`}>
                            <Icon className="h-4 w-4" />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center justify-between gap-2">
                              <p className="truncate text-sm font-medium">{EMERGENCY_META[i.type].label}</p>
                              <Badge variant="outline" className={`shrink-0 text-[10px] ${severityBg(i.severity)}`}>{i.severity}</Badge>
                            </div>
                            <p className="mt-0.5 truncate text-xs text-muted-foreground">{i.location.label ?? "Venue"} · {i.reporterName}</p>
                            <div className="mt-1.5 flex items-center justify-between text-[11px] text-muted-foreground">
                              <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{formatDistanceToNow(i.createdAt, { addSuffix: true })}</span>
                              <span className="flex items-center gap-1"><Sparkles className="h-3 w-3 text-accent" />P{Math.round(i.priorityScore)}</span>
                            </div>
                          </div>
                          <ChevronRight className="mt-2 h-4 w-4 shrink-0 text-muted-foreground transition-transform group-hover:translate-x-0.5" />
                        </div>
                      </button>
                    );
                  })}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </div>

        {/* Selected incident detail + Chat */}
        <div className="grid gap-4 lg:grid-cols-3">
          <div className="lg:col-span-2">
            {selected ? (
              <IncidentDetail
                incident={selected}
                responders={responders}
                onStatus={(s) => updateStatus(selected.id, s)}
                onAssign={(rid) => assignResponder(selected.id, rid)}
                onUnassign={(rid) => unassignResponder(selected.id, rid)}
              />
            ) : (
              <Card className="border-border/60 bg-card/60">
                <CardContent className="flex h-64 items-center justify-center text-muted-foreground">No incident selected.</CardContent>
              </Card>
            )}
          </div>
          <StaffChat />
        </div>

        {/* Analytics */}
        <div>
          <h2 className="mb-3 text-lg font-semibold">Analytics</h2>
          <AnalyticsCharts incidents={incidents} />
        </div>
      </main>
    </div>
  );
}

function KpiCard({ icon: Icon, label, value, accent }: { icon: typeof Activity; label: string; value: number | string; accent: "primary" | "critical" | "info" | "success" }) {
  const tones = {
    primary: "bg-primary/15 text-primary",
    critical: "bg-severity-critical/15 text-severity-critical",
    info: "bg-info/15 text-info",
    success: "bg-success/15 text-success",
  } as const;
  return (
    <Card className="border-border/60 bg-card/60">
      <CardContent className="flex items-center gap-4 p-4">
        <div className={`flex h-11 w-11 items-center justify-center rounded-xl ${tones[accent]}`}><Icon className="h-5 w-5" /></div>
        <div>
          <p className="text-xs uppercase tracking-wider text-muted-foreground">{label}</p>
          <p className="text-2xl font-bold">{value}</p>
        </div>
      </CardContent>
    </Card>
  );
}

function IncidentDetail({
  incident,
  responders,
  onStatus,
  onAssign,
  onUnassign,
}: {
  incident: Incident;
  responders: { id: string; name: string; department: string; available: boolean }[];
  onStatus: (s: IncidentStatus) => void;
  onAssign: (rid: string) => void;
  onUnassign: (rid: string) => void;
}) {
  const Icon = TYPE_ICON[incident.type];
  const assigned = responders.filter((r) => incident.assignedResponderIds.includes(r.id));
  const unassigned = responders.filter((r) => !incident.assignedResponderIds.includes(r.id));

  return (
    <Card className="border-border/60 bg-card/60">
      <CardHeader className="border-b border-border/40 pb-3">
        <div className="flex items-start gap-4">
          <div className={`flex h-11 w-11 items-center justify-center rounded-xl ${severityBg(incident.severity)}`}>
            <Icon className="h-5 w-5" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <CardTitle className="text-lg">{EMERGENCY_META[incident.type].label}</CardTitle>
              <Badge variant="outline" className={severityBg(incident.severity)}>{incident.severity}</Badge>
              <Badge variant="secondary" className="capitalize">{STATUS_META[incident.status].label}</Badge>
              {incident.panicCluster && <Badge variant="outline" className="border-severity-critical/40 bg-severity-critical/10 text-severity-critical">Panic cluster</Badge>}
            </div>
            <p className="mt-1 text-sm text-muted-foreground">{incident.description}</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-5 p-5">
        <div className="grid gap-3 sm:grid-cols-3">
          <DetailStat icon={MapPin} label="Location" value={incident.location.label ?? `${incident.location.lat.toFixed(4)}, ${incident.location.lng.toFixed(4)}`} />
          <DetailStat icon={Users} label="Reporter" value={`${incident.reporterName}${incident.reporterRoom ? ` · Room ${incident.reporterRoom}` : ""}`} />
          <DetailStat icon={Timer} label="ETA" value={`~${Math.ceil(incident.estimatedResponseSec / 60)} min`} />
          <DetailStat icon={Sparkles} label="Priority" value={`${Math.round(incident.priorityScore)} / 100`} accent="accent" />
          <DetailStat icon={Clock} label="Reported" value={formatDistanceToNow(incident.createdAt, { addSuffix: true })} />
          <DetailStat icon={CheckCircle2} label="Updated" value={formatDistanceToNow(incident.updatedAt, { addSuffix: true })} />
        </div>

        <div>
          <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Assigned responders</p>
          {assigned.length === 0 ? (
            <p className="rounded-lg border border-dashed border-border/60 bg-secondary/30 p-3 text-sm text-muted-foreground">No one assigned yet.</p>
          ) : (
            <div className="flex flex-wrap gap-2">
              {assigned.map((r) => (
                <Badge key={r.id} variant="outline" className="cursor-pointer gap-1.5 border-primary/40 bg-primary/10 py-1 text-primary hover:bg-primary/20" onClick={() => onUnassign(r.id)}>
                  {r.name} · {r.department}
                  <span className="text-xs opacity-60">×</span>
                </Badge>
              ))}
            </div>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Select onValueChange={(rid) => onAssign(rid)}>
            <SelectTrigger className="w-[260px]"><SelectValue placeholder="Assign a responder…" /></SelectTrigger>
            <SelectContent>
              {unassigned.length === 0 && <div className="px-2 py-1.5 text-sm text-muted-foreground">All assigned</div>}
              {unassigned.map((r) => (
                <SelectItem key={r.id} value={r.id}>{r.name} · {r.department}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <div className="ml-auto flex gap-2">
            {incident.status !== "in_progress" && incident.status !== "resolved" && (
              <Button variant="outline" onClick={() => onStatus("in_progress")}>Mark in progress</Button>
            )}
            {incident.status !== "resolved" && (
              <Button className="bg-success hover:bg-success/90" onClick={() => onStatus("resolved")}>
                <CheckCircle2 className="h-4 w-4" /> Resolve
              </Button>
            )}
            {incident.status === "resolved" && (
              <Button variant="outline" onClick={() => onStatus("in_progress")}>Re-open</Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function DetailStat({ icon: Icon, label, value, accent }: { icon: typeof Activity; label: string; value: string; accent?: "accent" }) {
  return (
    <div className="rounded-lg border border-border/60 bg-secondary/30 p-3">
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <Icon className={`h-3.5 w-3.5 ${accent === "accent" ? "text-accent" : ""}`} /> {label}
      </div>
      <p className="mt-1 text-sm font-medium">{value}</p>
    </div>
  );
}
