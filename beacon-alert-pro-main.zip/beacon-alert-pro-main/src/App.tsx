import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useEffect } from "react";
import { useAuthStore } from "@/lib/auth-store";
import { useIncidentStore } from "@/lib/incident-store";
import Landing from "./pages/Landing";
import AuthPage from "./pages/Auth";
import GuestApp from "./pages/GuestApp";
import Dashboard from "./pages/Dashboard";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

function RoleGate({ allow, children }: { allow: Array<"guest" | "staff" | "admin">; children: JSX.Element }) {
  const user = useAuthStore((s) => s.user);
  if (!user) return <Navigate to="/auth" replace />;
  if (!allow.includes(user.role)) {
    return <Navigate to={user.role === "guest" ? "/sos" : "/dashboard"} replace />;
  }
  return children;
}

const App = () => {
  const init = useIncidentStore((s) => s.init);
  const recompute = useIncidentStore((s) => s.recomputePriorities);

  useEffect(() => {
    init();
    const interval = setInterval(recompute, 15_000);
    return () => clearInterval(interval);
  }, [init, recompute]);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Landing />} />
            <Route path="/auth" element={<AuthPage />} />
            <Route path="/sos" element={<RoleGate allow={["guest", "staff", "admin"]}><GuestApp /></RoleGate>} />
            <Route path="/dashboard" element={<RoleGate allow={["staff", "admin"]}><Dashboard /></RoleGate>} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
