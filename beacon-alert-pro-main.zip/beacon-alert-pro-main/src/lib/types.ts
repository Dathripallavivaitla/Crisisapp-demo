// CrisisShield AI — Core domain types
export type EmergencyType = "fire" | "medical" | "security" | "evacuation" | "other";
export type Severity = "low" | "medium" | "high" | "critical";
export type IncidentStatus = "pending" | "in_progress" | "resolved";
export type UserRole = "guest" | "staff" | "admin";
export type Language = "en" | "es" | "fr" | "de";

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  room?: string; // for guests
  department?: string; // for staff
  language: Language;
}

export interface GeoLocation {
  lat: number;
  lng: number;
  label?: string;
}

export interface Responder {
  id: string;
  name: string;
  department: string;
  available: boolean;
}

export interface Incident {
  id: string;
  reporterId: string;
  reporterName: string;
  reporterRoom?: string;
  type: EmergencyType;
  severity: Severity;
  status: IncidentStatus;
  location: GeoLocation;
  description: string;
  createdAt: number;
  updatedAt: number;
  resolvedAt?: number;
  assignedResponderIds: string[];
  estimatedResponseSec: number;
  priorityScore: number;
  panicCluster?: boolean;
}

export interface ChatMessage {
  id: string;
  incidentId?: string; // null = general staff channel
  authorId: string;
  authorName: string;
  authorRole: UserRole;
  text: string;
  createdAt: number;
}

export interface SystemAlert {
  id: string;
  channel: "app" | "sms" | "email";
  recipient: string;
  body: string;
  createdAt: number;
}
