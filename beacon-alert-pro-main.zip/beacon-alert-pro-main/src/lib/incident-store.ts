import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Incident, ChatMessage, Responder, IncidentStatus, EmergencyType, Severity, GeoLocation, SystemAlert } from "./types";
import { VENUE, EMERGENCY_META } from "./constants";
import { computePriority, detectPanicCluster, estimateResponseSec, suggestSeverity } from "./ai";

const SEED_RESPONDERS: Responder[] = [
  { id: "r1", name: "Maria Santos", department: "Security", available: true },
  { id: "r2", name: "Devon Park", department: "Security", available: true },
  { id: "r3", name: "Priya Shah", department: "Medical", available: true },
  { id: "r4", name: "Tomás Oliveira", department: "Medical", available: true },
  { id: "r5", name: "Aiko Tanaka", department: "Fire Safety", available: true },
  { id: "r6", name: "Liam O'Connor", department: "Operations", available: true },
];

function jitterLocation(center: GeoLocation, meters: number): GeoLocation {
  const r = (meters * Math.random()) / 111_000;
  const theta = Math.random() * 2 * Math.PI;
  return { lat: center.lat + r * Math.cos(theta), lng: center.lng + r * Math.sin(theta) };
}

function seedIncidents(): Incident[] {
  const now = Date.now();
  const base: Omit<Incident, "id" | "priorityScore" | "estimatedResponseSec">[] = [
    {
      reporterId: "u-seed-1", reporterName: "Emma Wilson", reporterRoom: "208",
      type: "medical", severity: "high", status: "in_progress",
      location: { ...jitterLocation(VENUE.center, 80), label: "Pool Deck" },
      description: "Guest collapsed near the pool, conscious but disoriented.",
      createdAt: now - 1000 * 60 * 8, updatedAt: now - 1000 * 60 * 4,
      assignedResponderIds: ["r3"],
    },
    {
      reporterId: "u-seed-2", reporterName: "Noah Bennett", reporterRoom: "517",
      type: "security", severity: "medium", status: "pending",
      location: { ...jitterLocation(VENUE.center, 120), label: "5th Floor Hallway" },
      description: "Unknown person trying door handles in the hallway.",
      createdAt: now - 1000 * 60 * 3, updatedAt: now - 1000 * 60 * 3,
      assignedResponderIds: [],
    },
    {
      reporterId: "u-seed-3", reporterName: "Ava Martinez", reporterRoom: "302",
      type: "fire", severity: "low", status: "resolved",
      location: { ...jitterLocation(VENUE.center, 60), label: "Room 302" },
      description: "Burnt toast set off the smoke detector. False alarm.",
      createdAt: now - 1000 * 60 * 90, updatedAt: now - 1000 * 60 * 75,
      resolvedAt: now - 1000 * 60 * 75,
      assignedResponderIds: ["r5"],
    },
    {
      reporterId: "u-seed-4", reporterName: "Lucas Hayes", reporterRoom: "108",
      type: "medical", severity: "medium", status: "resolved",
      location: { ...jitterLocation(VENUE.center, 40), label: "Lobby Bar" },
      description: "Allergic reaction, treated on-site.",
      createdAt: now - 1000 * 60 * 60 * 4, updatedAt: now - 1000 * 60 * 60 * 3,
      resolvedAt: now - 1000 * 60 * 60 * 3,
      assignedResponderIds: ["r4"],
    },
    {
      reporterId: "u-seed-5", reporterName: "Mia Cooper", reporterRoom: "—",
      type: "other", severity: "low", status: "resolved",
      location: { ...jitterLocation(VENUE.center, 100), label: "Spa Reception" },
      description: "Spilled drink, slip hazard.",
      createdAt: now - 1000 * 60 * 60 * 24, updatedAt: now - 1000 * 60 * 60 * 23,
      resolvedAt: now - 1000 * 60 * 60 * 23,
      assignedResponderIds: ["r6"],
    },
  ];
  return base.map((b, i) => {
    const id = `i-seed-${i + 1}`;
    return {
      ...b,
      id,
      priorityScore: computePriority(b.severity, false, (Date.now() - b.createdAt) / 1000),
      estimatedResponseSec: estimateResponseSec(b.severity, b.assignedResponderIds.length),
    };
  });
}

const SEED_CHAT: ChatMessage[] = [
  { id: "c1", authorId: "r3", authorName: "Priya Shah", authorRole: "staff", text: "On scene at the pool — patient stable, requesting backup stretcher.", createdAt: Date.now() - 1000 * 60 * 6 },
  { id: "c2", authorId: "u-admin-demo", authorName: "Sam Okafor", authorRole: "admin", text: "Stretcher dispatched. Maintain channel.", createdAt: Date.now() - 1000 * 60 * 5 },
];

interface IncidentState {
  incidents: Incident[];
  responders: Responder[];
  chat: ChatMessage[];
  alerts: SystemAlert[];
  initialized: boolean;
  init: () => void;
  createIncident: (input: {
    reporterId: string;
    reporterName: string;
    reporterRoom?: string;
    type: EmergencyType;
    description: string;
    location: GeoLocation;
  }) => Incident;
  updateStatus: (id: string, status: IncidentStatus) => void;
  assignResponder: (incidentId: string, responderId: string) => void;
  unassignResponder: (incidentId: string, responderId: string) => void;
  postChat: (msg: Omit<ChatMessage, "id" | "createdAt">) => void;
  recomputePriorities: () => void;
}

export const useIncidentStore = create<IncidentState>()(
  persist(
    (set, get) => ({
      incidents: [],
      responders: SEED_RESPONDERS,
      chat: [],
      alerts: [],
      initialized: false,
      init: () => {
        if (get().initialized) return;
        set({ incidents: seedIncidents(), chat: SEED_CHAT, initialized: true });
      },
      createIncident: ({ reporterId, reporterName, reporterRoom, type, description, location }) => {
        const severity: Severity = suggestSeverity(type, description);
        const now = Date.now();
        const draft: Incident = {
          id: `i-${now}`,
          reporterId,
          reporterName,
          reporterRoom,
          type,
          severity,
          status: "pending",
          location,
          description: description || EMERGENCY_META[type].description,
          createdAt: now,
          updatedAt: now,
          assignedResponderIds: [],
          estimatedResponseSec: estimateResponseSec(severity, 0),
          priorityScore: 0,
        };
        const others = get().incidents;
        const panic = detectPanicCluster(draft, others);
        draft.panicCluster = panic;
        draft.priorityScore = computePriority(severity, panic, 0);
        const alerts: SystemAlert[] = [
          { id: `a-${now}-app`, channel: "app", recipient: "all-staff", body: `${EMERGENCY_META[type].label} reported by ${reporterName}`, createdAt: now },
          { id: `a-${now}-sms`, channel: "sms", recipient: "+1•••••• (on-call lead)", body: `[CrisisShield] ${severity.toUpperCase()} ${type} • ${location.label ?? "venue"}`, createdAt: now },
          { id: `a-${now}-email`, channel: "email", recipient: "ops@azurebay.example", body: `New ${severity} incident — ${type}`, createdAt: now },
        ];
        set((s) => ({ incidents: [draft, ...s.incidents], alerts: [...alerts, ...s.alerts].slice(0, 50) }));
        return draft;
      },
      updateStatus: (id, status) => {
        set((s) => ({
          incidents: s.incidents.map((i) =>
            i.id === id
              ? {
                  ...i,
                  status,
                  updatedAt: Date.now(),
                  resolvedAt: status === "resolved" ? Date.now() : i.resolvedAt,
                }
              : i
          ),
        }));
      },
      assignResponder: (incidentId, responderId) => {
        set((s) => ({
          incidents: s.incidents.map((i) => {
            if (i.id !== incidentId || i.assignedResponderIds.includes(responderId)) return i;
            const assigned = [...i.assignedResponderIds, responderId];
            return {
              ...i,
              assignedResponderIds: assigned,
              status: i.status === "pending" ? "in_progress" : i.status,
              updatedAt: Date.now(),
              estimatedResponseSec: estimateResponseSec(i.severity, assigned.length),
            };
          }),
        }));
      },
      unassignResponder: (incidentId, responderId) => {
        set((s) => ({
          incidents: s.incidents.map((i) => {
            if (i.id !== incidentId) return i;
            const assigned = i.assignedResponderIds.filter((r) => r !== responderId);
            return {
              ...i,
              assignedResponderIds: assigned,
              estimatedResponseSec: estimateResponseSec(i.severity, assigned.length),
              updatedAt: Date.now(),
            };
          }),
        }));
      },
      postChat: (msg) => {
        set((s) => ({
          chat: [...s.chat, { ...msg, id: `c-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, createdAt: Date.now() }],
        }));
      },
      recomputePriorities: () => {
        set((s) => ({
          incidents: s.incidents.map((i) =>
            i.status === "resolved"
              ? i
              : {
                  ...i,
                  priorityScore: computePriority(i.severity, !!i.panicCluster, (Date.now() - i.createdAt) / 1000),
                }
          ),
        }));
      },
    }),
    {
      name: "crisisshield-incidents",
      partialize: (s) => ({
        incidents: s.incidents,
        chat: s.chat,
        alerts: s.alerts,
        initialized: s.initialized,
        responders: s.responders,
      }),
    }
  )
);
