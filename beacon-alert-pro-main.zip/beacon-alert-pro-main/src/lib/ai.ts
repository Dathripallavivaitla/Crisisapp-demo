import type { EmergencyType, Severity, Incident } from "./types";
import { EMERGENCY_META, SEVERITY_META } from "./constants";

const SEVERITY_WEIGHT: Record<Severity, number> = {
  low: 1,
  medium: 2,
  high: 3,
  critical: 4,
};

/** Compute a 0-100 priority score for an incident.
 *  Inputs: severity, panic-cluster proximity, age. */
export function computePriority(
  severity: Severity,
  panicCluster: boolean,
  ageSeconds: number
): number {
  const sev = SEVERITY_WEIGHT[severity] * 18; // up to 72
  const cluster = panicCluster ? 18 : 0;
  const ageBoost = Math.min(10, Math.floor(ageSeconds / 60)); // +1 per minute, cap 10
  return Math.min(100, sev + cluster + ageBoost);
}

/** Estimated response time in seconds based on severity + assigned responders. */
export function estimateResponseSec(severity: Severity, assigned: number): number {
  const base = { low: 600, medium: 360, high: 180, critical: 90 }[severity];
  const speedup = Math.max(0.4, 1 - assigned * 0.15);
  return Math.round(base * speedup);
}

/** Detect if 2+ incidents within 60s & 60m radius — indicates panic / mass event. */
export function detectPanicCluster(target: Incident, others: Incident[]): boolean {
  const RADIUS_M = 60;
  const WINDOW_MS = 60_000;
  let count = 0;
  for (const o of others) {
    if (o.id === target.id) continue;
    if (Math.abs(o.createdAt - target.createdAt) > WINDOW_MS) continue;
    const dist = haversineMeters(target.location, o.location);
    if (dist <= RADIUS_M) count++;
  }
  return count >= 1; // target + 1 nearby = cluster of 2+
}

export function haversineMeters(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const R = 6371000;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

/** Suggest severity from emergency type + free-text keywords. */
export function suggestSeverity(type: EmergencyType, text: string): Severity {
  const base = EMERGENCY_META[type].severity;
  const t = text.toLowerCase();
  const escalators = ["unconscious", "bleeding heavily", "trapped", "spreading", "weapon", "many", "multiple", "can't breathe", "cant breathe", "collapsed"];
  if (escalators.some((k) => t.includes(k))) {
    const order: Severity[] = ["low", "medium", "high", "critical"];
    return order[Math.min(order.length - 1, order.indexOf(base) + 1)];
  }
  return base;
}

export function severityClass(severity: Severity): string {
  return `text-severity-${severity === "low" ? "low" : severity === "medium" ? "medium" : severity === "high" ? "high" : "critical"}`;
}

export function severityBg(severity: Severity): string {
  return severity === "low"
    ? "bg-severity-low/15 text-severity-low border-severity-low/30"
    : severity === "medium"
      ? "bg-severity-medium/15 text-severity-medium border-severity-medium/30"
      : severity === "high"
        ? "bg-severity-high/15 text-severity-high border-severity-high/30"
        : "bg-severity-critical/15 text-severity-critical border-severity-critical/30";
}

export { SEVERITY_META };
