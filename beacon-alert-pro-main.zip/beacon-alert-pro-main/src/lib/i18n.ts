import type { Language } from "./types";

type Dict = Record<string, string>;

const en: Dict = {
  "app.tagline": "Emergency Response & Crisis Coordination",
  "auth.welcome": "Welcome to CrisisShield AI",
  "auth.signin": "Sign in",
  "auth.signup": "Create account",
  "auth.email": "Email",
  "auth.password": "Password",
  "auth.name": "Full name",
  "auth.role": "I am a…",
  "auth.role.guest": "Guest",
  "auth.role.staff": "Staff member",
  "auth.role.admin": "Administrator",
  "auth.room": "Room number",
  "auth.department": "Department",
  "auth.demo": "Or try a demo account",
  "sos.title": "Emergency SOS",
  "sos.tap": "Tap to alert",
  "sos.holding": "Sending alert…",
  "sos.confirm": "Help is on the way",
  "sos.choose_type": "Choose emergency type",
  "sos.add_details": "Add details (optional)",
  "sos.placeholder": "e.g. Fire in the kitchen, two people trapped",
  "sos.use_voice": "Use voice",
  "sos.send": "Send alert",
  "sos.location": "Detected location",
  "sos.eta": "Estimated response",
  "dashboard.title": "Live Operations",
  "dashboard.feed": "Incident feed",
  "dashboard.map": "Venue map",
  "dashboard.charts": "Analytics",
  "dashboard.chat": "Staff channel",
  "common.logout": "Sign out",
  "common.language": "Language",
};

const es: Dict = {
  "app.tagline": "Respuesta a Emergencias y Coordinación de Crisis",
  "auth.welcome": "Bienvenido a CrisisShield AI",
  "auth.signin": "Iniciar sesión",
  "auth.signup": "Crear cuenta",
  "auth.email": "Correo",
  "auth.password": "Contraseña",
  "auth.name": "Nombre completo",
  "auth.role": "Soy…",
  "auth.role.guest": "Huésped",
  "auth.role.staff": "Personal",
  "auth.role.admin": "Administrador",
  "auth.room": "Número de habitación",
  "auth.department": "Departamento",
  "auth.demo": "O prueba una cuenta de demostración",
  "sos.title": "SOS de Emergencia",
  "sos.tap": "Toca para alertar",
  "sos.holding": "Enviando alerta…",
  "sos.confirm": "La ayuda está en camino",
  "sos.choose_type": "Tipo de emergencia",
  "sos.add_details": "Detalles (opcional)",
  "sos.placeholder": "ej. Incendio en la cocina, dos personas atrapadas",
  "sos.use_voice": "Usar voz",
  "sos.send": "Enviar alerta",
  "sos.location": "Ubicación detectada",
  "sos.eta": "Respuesta estimada",
  "dashboard.title": "Operaciones en Vivo",
  "dashboard.feed": "Feed de incidentes",
  "dashboard.map": "Mapa del recinto",
  "dashboard.charts": "Análisis",
  "dashboard.chat": "Canal del personal",
  "common.logout": "Cerrar sesión",
  "common.language": "Idioma",
};

const fr: Dict = {
  ...en,
  "app.tagline": "Réponse aux Urgences et Coordination de Crise",
  "auth.welcome": "Bienvenue sur CrisisShield AI",
  "auth.signin": "Connexion",
  "auth.signup": "Créer un compte",
  "sos.title": "SOS d’Urgence",
  "sos.tap": "Appuyez pour alerter",
  "sos.confirm": "Les secours arrivent",
  "common.logout": "Déconnexion",
};

const de: Dict = {
  ...en,
  "app.tagline": "Notfallreaktion & Krisenkoordination",
  "auth.welcome": "Willkommen bei CrisisShield AI",
  "auth.signin": "Anmelden",
  "auth.signup": "Konto erstellen",
  "sos.title": "Notruf SOS",
  "sos.tap": "Tippen zum Alarmieren",
  "sos.confirm": "Hilfe ist unterwegs",
  "common.logout": "Abmelden",
};

const DICTS: Record<Language, Dict> = { en, es, fr, de };

export function t(language: Language, key: string): string {
  return DICTS[language]?.[key] ?? DICTS.en[key] ?? key;
}
